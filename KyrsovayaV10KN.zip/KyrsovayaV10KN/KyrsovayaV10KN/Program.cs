﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KyrsovayaV10KN
{
    class Gosudarstvo
    {
        public Gosudarstvo()
        {
            oName = "xz";
            Population = 12;
            Square = 5;
        }
        public Gosudarstvo(string oName, int Population, float Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
        }
        protected string oName;
        protected int Population;
        protected float Square;
        public string retOname()
        {
            return oName;
        }
        public string retPop()
        {
            return Convert.ToString(Population);
        }
        public string retSq()
        {
            return string.Format("{0} кв.км", Square);
        }
        public string PrintAll()
        {
            return string.Format("Государство: {0}\nПлощадь: {1}\nНаселенние: {2}", oName, retSq(), Population);
        }
    }
    class Respublika : Gosudarstvo
    {
        public Respublika()
        {
            regName = "neva#no";
        }
        public Respublika(string oName, string regName, int Population, float Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
            this.regName = regName;
        }
        protected string regName;
        public string retRname()
        {
            return regName;
        }
        public string PrintAll()
        {
            return string.Format("Форма правления: {0}\nГосударство: {1}\nПлощадь: {2}\nНаселение: {3}", regName, oName, retSq(), Population);
        }
    }
    class Monarhiya : Respublika
    {
        public Monarhiya()
        {
            posName = "PosNeva#no";
        }
        public Monarhiya(string oName, string regName, string posName, int Population, float Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
            this.regName = regName;
            this.posName = posName;
        }
        protected string posName;
        public string retPosName()
        {
        return posName;
        }
        public string PrintAll()
        {
            return string.Format("Глава государства: {0} \nФорма правления: {1}\nГосудартво: {2} \nПлощадь: {3} \nНаселение: {4}", posName, regName, oName, retSq(), Population);
        }
    }
    class Korolevstvo : Respublika
    {
        public Korolevstvo()
        {
            cName = "Cityname";
        }
        public Korolevstvo(string oName, string regName, string cName, int Population, float Square)
        {
            this.oName = oName;
            this.Population = Population;
            this.Square = Square;
            this.regName = regName;
            this.cName = cName;
        }
        protected string cName;
        public string retCname()
        {
            return cName;
        }
        public string PrintAll()
        {
            return string.Format("Глава государства: {0}\nФорма правления: {1}\nГосударство: {2} \nПлощадь: {3} \nНаселение: {4}", cName, regName, oName, retSq(), Population);
        }
        class Program
        {
            static void Main(string[] args)
            {
                Gosudarstvo Obl1 = new Gosudarstvo("Великобритания", 54000, 32345);
                Respublika reg1 = new Respublika("Азейбарджан", "Республика", 2000, 5235);
                Monarhiya pos1 = new Monarhiya("Лихтенштейн", "Монархия", "Монарх", 350, 235);
                Korolevstvo city1 = new Korolevstvo("Испания", "Королевство", "Король", 350, 235);
                Console.WriteLine(Obl1.PrintAll());
                Console.WriteLine("---------------");
                Console.WriteLine(reg1.PrintAll());
                Console.WriteLine("---------------");
                Console.WriteLine(pos1.PrintAll());
                Console.WriteLine("---------------");
                Console.WriteLine(city1.PrintAll());
                Console.ReadKey();
            }
        }
    }
}
